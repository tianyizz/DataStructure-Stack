I didn't change GrahamScan header file.
